package data.mediaDB;

public interface Video extends MediaContentUploadable {
    int getWdth();
    int getHight();
    String getEncodng();
}
