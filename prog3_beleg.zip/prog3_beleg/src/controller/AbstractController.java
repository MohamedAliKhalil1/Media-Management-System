package controller;

import java.beans.PropertyChangeListener;

public abstract class AbstractController implements PropertyChangeListener {

}
