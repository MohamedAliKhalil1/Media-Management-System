package data.mediaDB;

public interface Uploader {
    String getProducerName();
}
