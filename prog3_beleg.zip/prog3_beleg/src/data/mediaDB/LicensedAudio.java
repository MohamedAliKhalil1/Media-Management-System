package data.mediaDB;

public interface LicensedAudio extends Licensed, Audio {
}
