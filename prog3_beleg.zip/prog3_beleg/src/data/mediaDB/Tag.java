package data.mediaDB;

public enum Tag {
    Animal,Tutorial,Lifestyle,News
}
