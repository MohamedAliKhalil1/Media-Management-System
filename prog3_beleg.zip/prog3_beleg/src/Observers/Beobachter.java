package Observers;

public interface Beobachter {
    void aktualisiere();
}
