package data.mediaDB;

public interface LicensedAudioVideo extends Licensed, AudioVideo {
}
