package data.mediaDB;

public interface LicensedVideo extends Licensed, Video {
}
