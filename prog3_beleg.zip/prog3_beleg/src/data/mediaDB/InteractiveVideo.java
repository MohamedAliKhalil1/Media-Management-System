package data.mediaDB;

public interface InteractiveVideo extends Video, Interactive {
}
