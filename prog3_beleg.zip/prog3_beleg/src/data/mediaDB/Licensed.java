package data.mediaDB;

public interface Licensed extends Content{
    String getHoldr();
}
