package data.mediaDB;

public interface AudioVideo extends Audio, Video {
}
