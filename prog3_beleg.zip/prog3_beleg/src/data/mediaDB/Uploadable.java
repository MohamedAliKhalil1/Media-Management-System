package data.mediaDB;

import java.util.Date;

public interface Uploadable extends Uploader {
    Date getDate();
}
